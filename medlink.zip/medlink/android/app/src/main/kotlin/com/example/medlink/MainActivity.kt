package com.example.medlink

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
